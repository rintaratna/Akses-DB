package com.example.konekdatabase

data class Fakultas(
    val id_fakultas: String, val kode_fakultas: String?
)